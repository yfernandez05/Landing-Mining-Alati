<div class="container-fluid p-0">

  <footer class="bg-primary text-center text-lg-start text-white">
    <!-- Grid container -->
    <div class="container p-4">
      <!--Grid row-->
      <div class="row mt-4 mb-0">
        <!--Grid column-->
        <div class="col-lg-3 col-md-12 mb-4 mb-md-0">

          <div class="rounded-circle bg-white shadow-1-strong d-flex align-items-center justify-content-center mb-4 mx-auto" style="width: 80px; height: 80px;">
            <img src="<?php echo e(asset('images/logo.png')); ?>" height="45" alt=""
                 loading="lazy" />
          </div>

          <p class="text-center">Especialistas en la formación de profesionales en Minería</p>

          <ul class="list-unstyled d-flex flex-row justify-content-center">
            <li>
              <a class="text-white px-2" href="#!">
                <i class="fab fa-facebook-square"></i>
              </a>
            </li>
            <li>
              <a class="text-white px-2" href="#!">
                <i class="fab fa-instagram"></i>
              </a>
            </li>
            <li>
              <a class="text-white ps-2" href="#!">
                <i class="fab fa-youtube"></i>
              </a>
            </li>
          </ul>

        </div>
        <!--Grid column-->

         <!--Grid column-->
         <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">Contacto</h5>

          <ul class="list-unstyled">
            <li>
              <p><i class="fas fa-map-marker-alt pe-2">&nbsp;</i>+51 974742246</p>
            </li>
            <li>
              <p><i class="fas fa-phone pe-2">&nbsp;</i>5116476428</p>
            </li>
            <li>
              <p><i class="fas fa-envelope pe-2 mb-0">&nbsp;</i>contact@example.com</p>
            </li>
          </ul>
        </div>

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">Ubícanos en</h5>

          <ul class="list-unstyled">
            <li class="mb-2">
              <a href="#!" class="text-white"><i class="fas fa-paw pe-3">&nbsp;</i>
                AV. Flora Tristán Nro. Urb. 212 - Santa Patricia I Etapa
                    Lima - Lima - La Molina
            </a>
            </li>           
          </ul>
        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
        © 2022 - Desarrollado por
      <a class="text-white" href="https://padin.com.pe/">Padin Publicidad digital

</a>
    </div>
    <!-- Copyright -->
  </footer>

</div>
<!-- End of .container --><?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\Prime Institute\MultiLandings\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>