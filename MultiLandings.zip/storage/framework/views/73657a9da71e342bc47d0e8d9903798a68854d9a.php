<?php $__env->startSection('content'); ?>


<section id="home" class="bg-secondary slider_home">
    <div class="container-fluid col-11 content_banner__home">
        <div class="row">
            <div class="col-12 col-md-7 col-lg-7 text-white text-info_banner">
                <h3 data-aos="fade-right">CERTIFÍCATE CON LIDERES INTERNACIONALES EN CAPACITACIÓN MINERA</h3>
                <!-- <p>El mercado laboral le solicita que se 
                    encuentre altamente capacitado con las 
                    últimas tecnologías de la información. 
                    Especialízate ahora!
                </p> -->
                <h5 class="d-none" data-aos="zoom-out-right" data-aos-duration="800">
                    <b class="text-success">Lidera exitosamente</b> las diferentes áreas de la <b class="text-success">Actividad Minera</b>
                </h5>                
            </div>

            <div class="col-sm justify-content-center cont-form" data-aos="fade-left"  data-aos-duration="800">
                <div class="col-12 col-md-12 col-lg-9 col-xl-8 align-self-center">
                    <div class="form-banner mdc-elevation--z2">
                        <h2 class="title-form-banner text-secondary text-center">Inscríbete aquí</h2>

                        <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>
                        <?php if(session('failed')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo e(session('failed')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>
                        <?php if(session('warning')): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <?php echo e(session('warning')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <?php endif; ?>

                        <form method="POST" name="fomr1" action="<?php echo e(route('store')); ?>" id="frmCliente">
                            <?php echo csrf_field(); ?>

                            <div class="form-row">
                                <div class="form-group col-12">
                                    <input type="text" class="form-control <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="nombres" id="nombres" value="<?php echo e(old('nombres')); ?>" placeholder="Nombres y Apellidos*">
                                    <span class="invalid-feedback" id="nombresError" role="alert"></span>
                                    <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>                            

                                <div class="form-group col-12">
                                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="email" id="email" value="<?php echo e(old('email')); ?>" placeholder="E-mail*" />
                                    <span class="invalid-feedback" id="emailError" role="alert"></span>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-group col-12">
                                    <input type="text" class="form-control pl-5 <?php $__errorArgs = ['celular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="celular" id="celular" value="<?php echo e(old('celular')); ?>" >
                                    <span class="invalid-feedback" id="celularError" role="alert"></span>
                                        <?php $__errorArgs = ['celular'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <!-- <input type="tel" id="celular" placeholder="">
                                    <span id="valid-msg" class="hide">✓ Valid</span>
                                        <span id="error-msg" class="hide"></span> -->
                                       
                                </div>                                

                                <div class="form-group col-12">
                                    <input type="text" class="form-control <?php $__errorArgs = ['profesion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="profesion" 
                                            value="<?php echo e(old('profesion')); ?>" placeholder="Profesión*">
                                    <?php $__errorArgs = ['profesion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> 

                                <div class="form-group col-12">
                                    <input type="text" class="form-control <?php $__errorArgs = ['empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="empresa" 
                                            value="<?php echo e(old('empresa')); ?>" placeholder="Empresa donde labora*">
                                    <?php $__errorArgs = ['empresa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div> 

                                <div class="form-group col-12">
                                    <div class="custom-control custom-checkbox <?php $__errorArgs = ['terminos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <input type="checkbox" class="custom-control-input" name="terminos" id="terminos"
                                            checked>
                                        <label class="custom-control-label terms-conditions" for="terminos">
                                            <span class="text-dark">Ud. acepta haber leído y aceptado </span>
                                            <a href="#" class="text-secondary" data-toggle="modal" data-target="#modalpoliticas">
                                                la Política de Privacidad.
                                            </a>
                                        </label>
                                    </div>
                                    <?php $__errorArgs = ['terminos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="form-group col-12">
                                    <input name="utm_source" id="utm_source" class="d-none"></input>
                                    <input name="utm_medium" id="utm_medium" class="d-none"></input>
                                    <input name="utm_campaign" id="utm_campaign" class="d-none"></input>
                                    <input name="utm_term" id="utm_term" class="d-none"></input>
                                    <input name="utm_content" id="utm_content" class="d-none"></input>
                                    <input name="procedencia" id="procedencia" class="d-none"></input>
                                </div>
                            </div>
                            <button class="btn btn-send_banner btn-secondary text-subtitulo btn-form mdc-elevation--z2">
                                Registrarme
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<section id="quienessomos" class="section_quienessomos bg-primary mb-3 py-4">
    <div class="container text-center pt-4 d-none d-md-block d-lg-none">
        <h2 class="text-white line-white"><span class="font-secondary">¿Quiénes</span> somos?</h2>
    </div> 
    <div class="container-fluid p-4 mt-3">
        <div class="col cont-fils">
            <div class="col-12 col-md-6 col-lg-4 cont-img d-none d-md-block img-colum" data-aos="fade-right" data-aos-duration="1000">
                <img src="<?php echo e(asset('images/quienes_somos.png')); ?>" alt="Quienes Somos" class="img p-3">
            </div>
            <div class="col-12 col-md-12 col-lg-7 cont-info" data-aos="zoom-rigth">
                <div class="container text-center pb-4 d-md-none d-lg-block">
                    <h2 class="text-white line-white"><span class="font-secondary">¿Quiénes</span> somos?</h2>
                </div> 
                <div class="col-12 col-md-6 col-lg-4 cont-img d-block d-md-none">
                    <img src="<?php echo e(asset('images/quienes_somos.png')); ?>" alt="Quienes Somos" class="img p-3">
                </div>              
                <span class="text-white my-3 long-text">
                Somos especialistas en la formación de profesionales en Minería.
                </span>
                <div class="text-white my-3">
                    <p>
                    Nuestro objetivo es garantizar un servicio de capacitación con conocimientos sólidos y acorde a las necesidades del mercado. 
                    </p>

                    <div class="col-12 cont-fils text-center my-4">
                        <div class="col-5 col-md-2 img-icons mb-3 mb-md-0">
                            <img src="<?php echo e(asset('images/icon_certificacion.png')); ?>" alt="logo quienes somos" class="img">
                        </div>
                        <div class="col-12 col-md-10 col-lg-10 align-self-center">
                            <p class="m-0">
                                <span class="font-primary">CERTIFICACIÓN INTERNACIONAL.</span>
                                Recibirás el Diploma, certificado de estudios y constancia de notas emitidos por Mining Alati.
                            </p>
                        </div>
                    </div>
                    <div class="col-12 cont-fils text-center my-4">
                        <div class="col-5 col-md-2 img-icons mb-3 mb-md-0">
                            <img src="<?php echo e(asset('images/icon_accesomulti.png')); ?>" alt="logo quienes somos" class="img">
                        </div>
                        <div class="col-12 col-md-10 col-lg-10 align-self-center">
                            <p class="m-0">
                                <span class="font-primary">ACCESO CONTINUO Y MULTIDISPOSITIVO.</span>
                                Podrás acceder las 24 horas del día al Campus Virtual, desde cualquier móvil, pc, tablet, etc.
                            </p>
                        </div>
                    </div>
                    <div class="col-12 cont-fils text-center my-4">
                        <div class="col-5 col-md-2 img-icons mb-3 mb-md-0">
                            <img src="<?php echo e(asset('images/icon_asesoriaacad.png')); ?>" alt="logo quienes somos" class="img">
                        </div>
                        <div class="col-12 col-md-10 col-lg-10 align-self-center">
                            <p class="m-0">
                                <span class="font-primary">ASESORÍA ACADÉMICA.</span>
                                Acompañamiento constante para que inicies, desarrolles y culmines tu programa satisfactoriamente.
                            </p>
                        </div>
                    </div>
                    <div class="col-12 cont-fils text-center my-4">
                        <div class="col-5 col-md-2 img-icons mb-3 mb-md-0">
                            <img src="<?php echo e(asset('images/icon_software.png')); ?>" alt="logo quienes somos" class="img">
                        </div>
                        <div class="col-12 col-md-10 col-lg-10 align-self-center">
                            <p class="m-0">
                                <span class="font-primary">USO E INTERPRETACIÓN DE SOFTWARE</span>
                                Nuestros programas especializados incluyen el uso e interpretación de softwares.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<section id="programas" class="section_cursos mb-3 py-4">
    <div class="container text-center py-4">
        <h2 class="text-primary line-primary"><span class="font-secondary">Cursos</span> destacados</h2>
    </div>
    <div class="container py-4" style=" overflow: hidden;">
        <div class="col-12 cont-fils">
            
            <div class="col-12 col-md-4 col-lg-3 curos_1" data-aos="fade-left" data-aos-duration="300">
                <figure class="cont-img_cursos">
                    <img src="<?php echo e(asset('images/curso_1.png')); ?>" alt="Costos y Presupuestos en Minería Superficial y Subterránea" class="img">
                    <figcaption class="info-curso">
                        <h2>
                        Costos y Presupuestos en Minería Superficial y Subterránea
                        </h2>
                    </figcaption>
                    <a href="#!" class="waves"></a>
                </figure>                 
            </div>

            <div class="col-12 col-md-4 col-lg-3 curos_1" data-aos="fade-right" data-aos-duration="300">
                <figure class="cont-img_cursos">
                    <img src="<?php echo e(asset('images/curso_2.png')); ?>" alt="Planeamiento de Minado y Cálculo de Reservas" class="img">
                    <figcaption class="info-curso">
                        <h2>
                        Planeamiento de Minado y Cálculo de Reservas
                        </h2>
                    </figcaption>
                    <a href="#!" class="waves"></a>
                </figure>                 
            </div>

            <div class="col-12 col-md-4 col-lg-3 curos_1" data-aos="fade-left" data-aos-duration="300">
                <figure class="cont-img_cursos">
                    <img src="<?php echo e(asset('images/curso_3.png')); ?>" alt="Geoestadística Aplicada a la Estimación de Yacimientos Mineros" class="img">
                    <figcaption class="info-curso">
                        <h2>
                        Geoestadística Aplicada a la Estimación de Yacimientos Mineros
                        </h2>
                    </figcaption>
                    <a href="#!" class="waves"></a>
                </figure>                 
            </div>

            <div class="col-12 col-md-4 col-lg-3 curos_1" data-aos="fade-right" data-aos-duration="300">
                <figure class="cont-img_cursos">
                    <img src="<?php echo e(asset('images/curso_4.png')); ?>" alt="Plantas de procesamiento de minerales" class="img">
                    <figcaption class="info-curso">
                        <h2>
                        Plantas de procesamiento de minerales
                        </h2>
                    </figcaption>
                    <a href="#!" class="waves"></a>
                </figure>                 
            </div>

            <div class="col-12 col-md-4 col-lg-3 curos_1" data-aos="fade-left" data-aos-duration="300">
                <figure class="cont-img_cursos">
                    <img src="<?php echo e(asset('images/curso_5.png')); ?>" alt="Hidrogeología Minera Avanzada" class="img">
                    <figcaption class="info-curso">
                        <h2>
                        Hidrogeología Minera Avanzada
                        </h2>
                    </figcaption>
                    <a href="#!" class="waves"></a>
                </figure>                 
            </div>
            
            <div class="col-12 col-md-4 col-lg-3 curos_1" data-aos="fade-right" data-aos-duration="300">
                <figure class="cont-img_cursos">
                    <img src="<?php echo e(asset('images/curso_6.png')); ?>" alt="Perforación y Voladura en Minería Subterránea" class="img">
                    <figcaption class="info-curso">
                        <h2>
                        Perforación y Voladura en Minería Subterránea
                        </h2>
                    </figcaption>
                    <a href="#!" class="waves"></a>
                </figure>                 
            </div>
            <div class="col-12 col-md-4 col-lg-3 curos_1" data-aos="fade-left" data-aos-duration="300">
                <figure class="cont-img_cursos">
                    <img src="<?php echo e(asset('images/curso_6.png')); ?>" alt="Perforación y Voladura en Minería Subterránea" class="img">
                    <figcaption class="info-curso">
                        <h2>
                        Perforación y Voladura en Minería Subterránea
                        </h2>
                    </figcaption>
                    <a href="#!" class="waves"></a>
                </figure>                 
            </div>
            <div class="col-12 col-md-4 col-lg-3 curos_1" data-aos="fade-right" data-aos-duration="300">
                <figure class="cont-img_cursos">
                    <img src="<?php echo e(asset('images/curso_6.png')); ?>" alt="Perforación y Voladura en Minería Subterránea" class="img">
                    <figcaption class="info-curso">
                        <h2>
                        Perforación y Voladura en Minería Subterránea
                        </h2>
                    </figcaption>
                    <a href="#!" class="waves"></a>
                </figure>                 
            </div>

        </div>
    </div>
</section>




<section id="porqueelegirnos" class="section_porqueelegirnos bg-primary mb-3 py-4">
    <div class="container text-center py-4">
        <h2 class="text-white line-white"><span class="font-secondary">¿Por qué</span> elegirnos?</h2>
    </div>
    <div class="container-fluid px-4 px-md-5" data-aos="fade-up" data-aos-duration="550">
        <div class="col-12 cont-fils cont-degrade mb-4">
            <div class="col-12 col-md-6 col-lg-3 cont-icons py-3">
                <div class="icon-img pb-3">
                    <img src="<?php echo e(asset('images/icon_100k.png')); ?>" alt="+100k estudiantes de todo el mundo" class="img">
                </div>                    
                <h3 class="text-white text-center">+7200 Alumnos certificados laborando</h3>
                <p class="text-white text-center">Respaldan nuestro compromiso por la educación.</p>
            </div>
            <div class="col-12 col-md-6 col-lg-3 cont-icons py-3">
                <div class="icon-img pb-3">
                    <img src="<?php echo e(asset('images/icon_empresas.png')); ?>" alt="+100k estudiantes de todo el mundo" class="img">
                </div>                    
                <h3 class="text-white text-center">+2000 empresas mineras</h3>
                <p class="text-white text-center">Confían en nosotros.</p>
            </div>
            <div class="col-12 col-md-6 col-lg-3 cont-icons py-3">
                <div class="icon-img pb-3">
                    <img src="<?php echo e(asset('images/icon_9anios.png')); ?>" alt="+100k estudiantes de todo el mundo" class="img">
                </div>                    
                <h3 class="text-white text-center">+9 años de experiencia y calidad</h3>
                <p class="text-white text-center">Brindando excelencia en nuestros servicios.</p>
            </div>
            <div class="col-12 col-md-6 col-lg-3 cont-icons py-3">
                <div class="icon-img pb-3">
                    <img src="<?php echo e(asset('images/icon_convenio_inter.png')); ?>" alt="+100k estudiantes de todo el mundo" class="img">
                </div>                    
                <h3 class="text-white text-center">Convenios internacionales</h3>
                <p class="text-white text-center">con la UPC de España y UC de Ecuador.</p>
            </div>
        </div>
    </div>
</section>




<section id="testimonios" class="section_testimonios mb-3 py-4">
    <div class="container text-center py-4">
        <h2 class="text-primary line-primary"><span class="font-secondary">Nuestros estudiantes</span> nos recomiendan</h2>
    </div>

    <div class="container-fluid px-4" data-aos="fade-up" data-aos-duration="600">
        <div class="col-12 cont-fils text-center slider-testimonios" >

            <div class="col-11 col-md-10 col-lg-11 m-2 p-3 cont-shadow bg-white rounded">
                <div class="col-12 mb-3">
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                </div>
                <div class="cont-texto">
                    <div class="text-info_testimonio">
                        <p>
                        Me ha gustado interactuar con profesionales de otras nacionalidades y que nos cuenten sus experiencias,
                        esas son cosas que nos nutren y nos muestran que la minería peruana está a la vanguardia.                       
                        </p>
                    </div>
                    <div class="row cont-profile">
                        <div class="col-4">
                            <img src="<?php echo e(asset('images/profile_testimonio_1.png')); ?>" alt="testimonio de PAÚL CAJAHUANCA" class="img rounded-circle">
                        </div>
                        <div class="col-8 name-profile">
                            <h4>
                            Ing. Paúl Cajahuanca
                            </h4>                            
                             Jefe de proyectos                            
                        </div>                        
                    </div>
                </div>
            </div>

            <div class="col-11 col-md-10 col-lg-11 m-2 p-3 cont-shadow bg-white rounded">
                <div class="col-12 mb-3">
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                </div>
                <div class="cont-texto">
                    <div class="text-info_testimonio">
                        <p>
                        Gracias al diplomado pude complementar y aprender más acerca de geomecánica, 
                        las clases son buenas y el material de apoyo también. Lo recomiendo totalmente. 
                        Muy agradecido de Mining Alati.                        
                        </p>
                    </div>
                    <div class="row cont-profile">
                        <div class="col-4">
                            <img src="<?php echo e(asset('images/profile_testimonio_2.png')); ?>" alt="testimonio de Victor Silva" class="img rounded-circle">
                        </div>
                        <div class="col-8 name-profile">
                            <h4>
                            Ing. Victor Silva
                            </h4>
                            Ing. de modelamiento
                        </div>                        
                    </div>
                </div>
            </div>

            <div class="col-11 col-md-10 col-lg-11 m-2 p-3 cont-shadow bg-white rounded">
                <div class="col-12 mb-3">
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                    <i class="fas fa-star text-warning text-shadow"></i>
                </div>
                <div class="cont-texto">
                    <div class="text-info_testimonio">
                        <p>
                        Cumplió mis expectativas, el Ing. Carlos (Expositor) tiene mucha experiencia y 
                        sabe compartir sus conocimientos.                        
                        </p>
                    </div>
                    <div class="row cont-profile">
                        <div class="col-4">
                            <img src="<?php echo e(asset('images/profile_testimonio_3.png')); ?>" alt="testimonio de Julian Alvares" class="img rounded-circle">
                        </div>
                        <div class="col-8 name-profile">
                            <h4>
                            Julian Alvares
                            </h4>
                            Cliente
                        </div>                        
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>




<section id="clientes" class="section_clientes mb-3 py-4">
    <div class="container text-center py-4">
        <h2 class="text-primary line-primary"><span class="font-secondary">Nuestros</span> Clientes</h2>
    </div>

    <div class="container-fluid px-4 d-flex justify-content-center">
        <div class="slider-clientes col-12 col-md-12 col-lg-10">        
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_1.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_2.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_3.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_4.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_5.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_6.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_7.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_8.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_9.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_10.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_11.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
            <div class="col-11 col-md-10 col-lg-11 m-1 p-3">
                <div class="cont-imgs">
                    <div class="img_clientes col-12">
                        <img src="<?php echo e(asset('images/cliente_12.png')); ?>" alt="clientes" class="img">
                    </div>                
                </div>
            </div>
        </div>
    </div>

</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\Prime Institute\MultiLandings\resources\views/welcome.blade.php ENDPATH**/ ?>