

<?php $__env->startSection('css'); ?>
<style>
    footer{
        position: absolute;
    bottom: 0;
    width: 100%;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<header class="main-banner" id="main-banner">
    <div class="container ">
        <div class="row justify-content-between content-main-banner">
            <div class="contenido-banner col-12 col-md-12 mt-5">
                <!-- <div class="d-md-block col-2 mt-5">
                    <img src="<?php echo e(asset('images\logo.png')); ?>" alt="Feria" class="img" height="60px">
                </div> -->
                <div class="container col-12 ">
                    <div class="text-banner ">
                        <h2 class="subtitle-banner text-primary">
                            Gracias por registrarte 
                        </h2>
                    </div>
                    <div class="text-banner ">
                        <h2 class="subtitle-banner ">
                            Un asesor(a) especializado se pondrá pronto en contacto contigo. 
                        </h2>
                    </div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-12 text-center text-md-center text-lg-left text-xl-left  pb-5 ">
                         <a class="btn btn-success rounded-pill px-5" href="<?php echo e(url('/')); ?>">
                            Ir a inicio
                         </a>                       
                        </div>
                    </div>
                 </div>
            </div>            

        </div>
    </div>
    
    </div>

</header>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\Prime Institute\MultiLandings\resources\views/thanks.blade.php ENDPATH**/ ?>