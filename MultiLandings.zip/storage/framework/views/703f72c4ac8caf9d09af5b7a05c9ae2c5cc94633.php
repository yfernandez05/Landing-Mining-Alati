<div class="container d-flex justify-content-center">
    <div class="slider-clientes col-12 col-md-12 col-lg-12">        
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_1.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_2.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_3.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_4.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_5.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_6.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_7.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_8.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_9.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_10.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_11.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
        <div class="col-11 col-lg-12 m-1 p-3">
            <div class="cont-imgs">
                <div class="img_clientes col-12">
                    <img src="<?php echo e(asset('images/cliente_12.png')); ?>" alt="clientes" class="img">
                </div>                
            </div>
        </div>
    </div>
</div><?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\Prime Institute\MultiLandings\resources\views/layouts/partials/utils/clientes.blade.php ENDPATH**/ ?>