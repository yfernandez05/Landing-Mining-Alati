<a class="back-top" href="#home">
    <i class="fas fa-arrow-circle-up"></i>
</a>
<?php /**PATH D:\WordPressEmpresas\ESCRITORIO Y MAS ARCHIVOS\Desarrollo\PadinSolution\system\Prime Institute\MultiLandings\resources\views/layouts/partials/utils/backtop.blade.php ENDPATH**/ ?>